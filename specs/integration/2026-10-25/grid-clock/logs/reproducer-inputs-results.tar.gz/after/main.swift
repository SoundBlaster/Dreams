import Foundation
let target = 9 * 3600.0 * 0.43
var rain = MatrixSimulation(columnCount: 110, rows: 72, glyphCount: 87, density: 1, fadeRows: 3,
                            deceleration: .init(enabled: true, acceleration: -37.5), startTime: max(0, target - 6))
rain.setSearchFraction(0.2)
let began = ProcessInfo.processInfo.systemUptime
rain.advance(to: target)
let seconds = ProcessInfo.processInfo.systemUptime - began
let result: [String: Any] = ["scenario": "new-grid-after-nine-hour-session", "target": target,
                           "advanceWallSeconds": seconds, "visible": rain.visibleSymbolCount,
                           "simulationTime": rain.time]
let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
print(String(decoding: data, as: UTF8.self))
